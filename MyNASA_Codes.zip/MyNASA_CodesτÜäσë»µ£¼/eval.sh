python eval_scripts/ppi_eval.py  ./example_data/ graphsage/unsup-example_data/graphsage_small_0.000010/  val
